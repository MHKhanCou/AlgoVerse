# algoverse/__init__.py

"""
AlgoVerse Package: Provides database models, schemas, and CRUD logic
for the AlgoVerse algorithm learning platform.
"""

__version__ = "0.2.0"