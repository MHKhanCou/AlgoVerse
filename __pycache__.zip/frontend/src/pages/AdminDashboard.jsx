import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { adminService } from '../services/adminService';
import DashboardStats from '../components/admin/DashboardStats';
import ManageUsers from '../components/admin/ManageUsers';
import ManageAlgoTypes from '../components/admin/ManageAlgoTypes';
import ManageAlgorithms from '../components/admin/ManageAlgorithms';
import ManageUserProgress from '../components/admin/ManageUserProgress';
import ManageBlogs from '../components/admin/ManageBlogs';
import HelpSection from '../components/admin/HelpSection';
import Sidebar from '../components/admin/Sidebar';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [dashboardStats, setDashboardStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [algoTypes, setAlgoTypes] = useState([]);
  const [algorithms, setAlgorithms] = useState([]);
  const [userProgress, setUserProgress] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch dashboard stats on mount
  useEffect(() => {
    const fetchInitialData = async () => {
      setLoading(true);
      try {
        const stats = await adminService.fetchDashboardStats();
        setDashboardStats(stats);
      } catch (error) {
        toast.error(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchInitialData();
  }, []);

  // Fetch users
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await adminService.fetchUsers();
      setUsers(data);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Fetch algorithm types
  const fetchAlgoTypes = async () => {
    setLoading(true);
    try {
      const data = await adminService.fetchAlgoTypes();
      setAlgoTypes(data);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Fetch algorithms
  const fetchAlgorithms = async () => {
    setLoading(true);
    try {
      const data = await adminService.fetchAlgorithms();
      setAlgorithms(data);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Fetch user progress
  const fetchUserProgress = async () => {
    setLoading(true);
    try {
      const data = await adminService.fetchUserProgress();
      setUserProgress(data);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Fetch blogs
  const fetchBlogs = async () => {
    setLoading(true);
    try {
      const data = await adminService.fetchBlogs();
      setBlogs(data);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Handle section change with lazy loading
  const handleSectionChange = (section) => {
    setActiveSection(section);
    setSearchQuery(''); // Reset search when changing sections
    if (section === 'users' && users.length === 0) fetchUsers();
    if (section === 'algo-types' && algoTypes.length === 0) fetchAlgoTypes();
    if (section === 'algorithms' && algorithms.length === 0) fetchAlgorithms();
    if (section === 'progress' && userProgress.length === 0) fetchUserProgress();
    if (section === 'blogs' && blogs.length === 0) fetchBlogs();
  };

  return (
    <div className="admin-dashboard">
      <header className="dashboard-header">
        <h1>Admin Dashboard</h1>
        {activeSection !== 'dashboard' && (
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-bar"
          />
        )}
      </header>
      <div className="dashboard-container">
        <Sidebar activeSection={activeSection} setActiveSection={handleSectionChange} />
        <main className="dashboard-content">
          {loading && <div className="loading">Loading...</div>}
          {activeSection === 'dashboard' && <DashboardStats stats={dashboardStats} />}
          {activeSection === 'users' && (
            <ManageUsers
              users={users}
              searchQuery={searchQuery}
              fetchUsers={fetchUsers}
              adminService={adminService}
            />
          )}
          {activeSection === 'algo-types' && (
            <ManageAlgoTypes
              algoTypes={algoTypes}
              searchQuery={searchQuery}
              fetchAlgoTypes={fetchAlgoTypes}
              adminService={adminService}
            />
          )}
          {activeSection === 'algorithms' && (
            <ManageAlgorithms
              algorithms={algorithms}
              algoTypes={algoTypes}
              searchQuery={searchQuery}
              fetchAlgorithms={fetchAlgorithms}
              adminService={adminService}
            />
          )}
          {activeSection === 'progress' && (
            <ManageUserProgress
              userProgress={userProgress}
              users={users}
              algorithms={algorithms}
              searchQuery={searchQuery}
              fetchUserProgress={fetchUserProgress}
              adminService={adminService}
            />
          )}
          {activeSection === 'blogs' && (
            <ManageBlogs
              blogs={blogs}
              searchQuery={searchQuery}
              fetchBlogs={fetchBlogs}
              adminService={adminService}
            />
          )}
          {activeSection === 'help' && <HelpSection />}
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;