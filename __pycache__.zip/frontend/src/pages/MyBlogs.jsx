import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';
import '../styles/MyBlogs.css';

const MyBlogs = () => {
  const { isAuthenticated, user } = useAuth();
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const fetchMyBlogs = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:8000/profile/my-blogs', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setBlogs(response.data);
      } catch (error) {
        toast.error('Failed to fetch your blogs', { theme: 'dark' });
      }
    };
    fetchMyBlogs();
  }, [isAuthenticated]);

  if (!isAuthenticated) {
    return <div className="error">Please log in to view your blogs.</div>;
  }

  return (
    <div className="my-blogs-container">
      <h1>My Blogs</h1>
      <Link to="/blogs" className="cta-button secondary">
        Back to All Blogs
      </Link>
      <div className="blogs-list">
        {blogs.length === 0 ? (
          <p>You haven't created any blogs yet.</p>
        ) : (
          blogs.map((blog) => (
            <div key={blog.id} className="blog-card">
              <Link to={`/blogs/${blog.id}`} className="blog-title">
                <h3>{blog.title}</h3>
              </Link>
              <p className="blog-author">By {blog.author}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default MyBlogs;