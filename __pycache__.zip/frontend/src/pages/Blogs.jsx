import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';
import '../styles/Blogs.css';

const Blogs = () => {
  const { isAuthenticated, user, isAdmin } = useAuth();
  const [blogs, setBlogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const navigate = useNavigate();

  // Fetch all blogs on mount
  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await axios.get('http://localhost:8000/blogs/');
        setBlogs(response.data);
      } catch (error) {
        toast.error('Failed to fetch blogs', { theme: 'dark' });
      }
    };
    fetchBlogs();
  }, []);

  // Handle search
  useEffect(() => {
    const fetchSearchResults = async () => {
      if (!searchQuery) {
        const response = await axios.get('http://localhost:8000/blogs/');
        setBlogs(response.data);
        return;
      }
      try {
        const response = await axios.get(`http://localhost:8000/blogs/search/${encodeURIComponent(searchQuery)}`);
        setBlogs(response.data);
      } catch (error) {
        toast.error('Search failed', { theme: 'dark' });
      }
    };
    fetchSearchResults();
  }, [searchQuery]);

  // Create blog
  const handleCreateBlog = async (e) => {
    e.preventDefault();
    if (!title || !body) {
      toast.error('Title and body are required', { theme: 'dark' });
      return;
    }
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:8000/blogs/',
        { title, body },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Blog created successfully', { theme: 'dark' });
      setTitle('');
      setBody('');
      setShowCreateForm(false);
      // Refresh blogs
      const response = await axios.get('http://localhost:8000/blogs/');
      setBlogs(response.data);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create blog', { theme: 'dark' });
    }
  };

  return (
    <div className="blogs-container">
      <h1>Blogs</h1>
      <div className="blogs-header">
        <input
          type="text"
          placeholder="Search blogs..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-input"
        />
        {isAuthenticated && (
          <div className="user-actions">
            <button
              className="cta-button primary"
              onClick={() => setShowCreateForm(!showCreateForm)}
            >
              {showCreateForm ? 'Cancel' : 'Create Blog'}
            </button>
            <Link to="/my-blogs" className="cta-button secondary">
              Manage My Blogs
            </Link>
          </div>
        )}
      </div>

      {showCreateForm && isAuthenticated && (
        <form className="create-blog-form" onSubmit={handleCreateBlog}>
          <input
            type="text"
            placeholder="Blog Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="form-input"
          />
          <textarea
            placeholder="Blog Content"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            className="form-textarea"
          />
          <button type="submit" className="cta-button primary">
            Submit Blog
          </button>
        </form>
      )}

      <div className="blogs-list">
        {blogs.length === 0 ? (
          <p>No blogs found</p>
        ) : (
          blogs.map((blog) => (
            <div key={blog.id} className="blog-card">
              <Link to={`/blogs/${blog.id}`} className="blog-title">
                <h3>{blog.title}</h3>
              </Link>
              <p className="blog-author">By {blog.author}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Blogs;