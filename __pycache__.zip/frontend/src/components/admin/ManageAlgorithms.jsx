import React, { useState } from 'react';
import { toast } from 'react-toastify';

const ManageAlgorithms = ({ algorithms, algoTypes, fetchAlgorithms, adminService }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    difficulty: '',
    complexity: '',
    type_id: '',
    code: '',
    explanation: '',
  });

  const isFormValid = () =>
    formData.name.trim() &&
    formData.description.trim() &&
    ['Easy', 'Medium', 'Hard'].includes(formData.difficulty) &&
    ['O(1)', 'O(logN)', 'O(N)', 'O(N log N)', 'O(N^2)', 'O(2^N)'].includes(formData.complexity) &&
    formData.type_id;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isFormValid()) {
      toast.error('Please fill in all required fields correctly');
      return;
    }

    const payload = {
      name: formData.name.trim(),
      description: formData.description.trim(),
      difficulty: formData.difficulty,
      complexity: formData.complexity,
      type_id: parseInt(formData.type_id),
      code: formData.code.trim() || null,
      explanation: formData.explanation.trim() || null,
    };

    console.log('Creating algorithm with payload:', payload); // Debug log

    try {
      await adminService.createAlgorithm(payload);
      await fetchAlgorithms();
      setFormData({
        name: '',
        description: '',
        difficulty: '',
        complexity: '',
        type_id: '',
        code: '',
        explanation: '',
      });
      toast.success('Algorithm created successfully');
    } catch (error) {
      console.error('Algorithm creation error:', error);
      toast.error(error.response?.data?.detail || 'Failed to create algorithm');
    }
  };

  const updateAlgorithm = async (algoId) => {
    const algo = algorithms.find((a) => a.id === algoId);
    const newName = prompt('Enter new name:', algo.name);
    const newDescription = prompt('Enter new description:', algo.description);
    const newDifficulty = prompt('Enter new difficulty (Easy/Medium/Hard):', algo.difficulty);
    const newComplexity = prompt('Enter new complexity (O(1)/O(logN)/O(N)/O(N log N)/O(N^2)/O(2^N)):', algo.complexity);
    const newTypeId = prompt('Enter new type ID:', algo.type_id);
    const newCode = prompt('Enter new code:', algo.code);
    const newExplanation = prompt('Enter new explanation:', algo.explanation);

    if (newName && newDescription && newDifficulty && newComplexity && newTypeId) {
      try {
        await adminService.updateAlgorithm(algoId, {
          name: newName,
          description: newDescription,
          difficulty: newDifficulty,
          complexity: newComplexity,
          type_id: parseInt(newTypeId),
          code: newCode || null,
          explanation: newExplanation || null,
        });
        await fetchAlgorithms();
        toast.success('Algorithm updated');
      } catch (error) {
        toast.error(error.response?.data?.detail || 'Failed to update algorithm');
      }
    }
  };

  const deleteAlgorithm = async (algoId) => {
    if (window.confirm('Are you sure you want to delete this algorithm?')) {
      try {
        await adminService.deleteAlgorithm(algoId);
        await fetchAlgorithms();
        toast.success('Algorithm deleted');
      } catch (error) {
        toast.error(error.response?.data?.detail || 'Failed to delete algorithm');
      }
    }
  };

  return (
    <section className="manage-section">
      <h2>Manage Algorithms</h2>
      <form onSubmit={handleSubmit} className="create-form">
        <input
          type="text"
          placeholder="Algorithm Name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          required
        />
        <textarea
          placeholder="Algorithm Code (optional)"
          value={formData.code}
          onChange={(e) => setFormData({ ...formData, code: e.target.value })}
        />
        <textarea
          placeholder="Algorithm Explanation (optional)"
          value={formData.explanation}
          onChange={(e) => setFormData({ ...formData, explanation: e.target.value })}
        />
        <select
          value={formData.difficulty}
          onChange={(e) => setFormData({ ...formData, difficulty: e.target.value })}
          required
        >
          <option value="">Select Difficulty</option>
          <option value="Easy">Easy</option>
          <option value="Medium">Medium</option>
          <option value="Hard">Hard</option>
        </select>
        <select
          value={formData.complexity}
          onChange={(e) => setFormData({ ...formData, complexity: e.target.value })}
          required
        >
          <option value="">Select Complexity</option>
          <option value="O(1)">O(1)</option>
          <option value="O(logN)">O(logN)</option>
          <option value="O(N)">O(N)</option>
          <option value="O(N log N)">O(N log N)</option>
          <option value="O(N^2)">O(N^2)</option>
          <option value="O(2^N)">O(2^N)</option>
        </select>
        <select
          value={formData.type_id}
          onChange={(e) => setFormData({ ...formData, type_id: e.target.value })}
          required
        >
          <option value="">Select Algorithm Type</option>
          {algoTypes.map((type) => (
            <option key={type.id} value={type.id}>
              {type.name}
            </option>
          ))}
        </select>
        <button type="submit" disabled={!isFormValid()}>
          Create
        </button>
      </form>
      <table className="dashboard-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Type</th>
            <th>Difficulty</th>
            <th>Complexity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {algorithms.length > 0 ? (
            algorithms.map((algo) => (
              <tr key={algo.id}>
                <td>{algo.id}</td>
                <td>{algo.name}</td>
                <td>{algo.type_name || 'Unknown'}</td>
                <td>{algo.difficulty}</td>
                <td>{algo.complexity}</td>
                <td>
                  <button onClick={() => updateAlgorithm(algo.id)} className="action-btn edit">
                    Edit
                  </button>
                  <button onClick={() => deleteAlgorithm(algo.id)} className="action-btn delete">
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6">No algorithms found.</td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
};

export default ManageAlgorithms;