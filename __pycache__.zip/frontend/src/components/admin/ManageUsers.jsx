import React from 'react';
import { toast } from 'react-toastify';

const ManageUsers = ({ users, searchQuery, fetchUsers, adminService }) => {
  const makeAdmin = async (userId) => {
    if (window.confirm('Make this user an admin?')) {
      try {
        await adminService.makeAdmin(userId);
        await fetchUsers();
        toast.success('User promoted to admin');
      } catch (error) {
        toast.error(error.response?.data?.detail || 'Failed to make admin');
      }
    }
  };

  const deleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        await adminService.deleteUser(userId);
        await fetchUsers();
        toast.success('User deleted');
      } catch (error) {
        toast.error(error.response?.data?.detail || 'Failed to delete user');
      }
    }
  };

  const filteredUsers = users.filter((user) =>
    (user.name || user.email || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="manage-section">
      <h2>Manage Users</h2>
      <table className="dashboard-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name || 'N/A'}</td>
                <td>{user.email}</td>
                <td>{user.is_admin ? 'Admin' : 'User'}</td>
                <td>
                  {!user.is_admin && (
                    <button onClick={() => makeAdmin(user.id)} className="action-btn make-admin">
                      Make Admin
                    </button>
                  )}
                  <button onClick={() => deleteUser(user.id)} className="action-btn delete">
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5">No users found.</td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
};

export default ManageUsers;